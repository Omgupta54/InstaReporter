# coding=utf-8
#!/usr/bin/env python3
from random import choice
from colorama import  Fore,Style,Back

logo =  """ 

█████╗  █████╗ ██████╗ ██╗  ██╗
██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝
██║  ██║███████║██████╔╝█████╔╝ 
██║  ██║██╔══██║██╔══██╗██╔═██╗ 
█████╔╝██║  ██║██║  ██║██║  ██╗
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝
                                
███████╗ ██████╗ ██╗   ██╗ █████╗ ██████╗ 
██╔════╝██╔═══██╗██║   ██║██╔══██╗██╔══██╗
███████╗██║   ██║██║   ██║███████║██║  ██║
╚════██║██║▄▄ ██║██║   ██║██╔══██║██║  ██║
███████║╚██████╔╝╚██████╔╝██║  ██║██████╔╝
╚══════╝ ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═╝╚═════╝ 

█ █▄░█ █▀ ▀█▀ ▄▀█
█ █░▀█ ▄█ ░█░ █▀█

█▀█ █▀▀ █▀█ █▀█ █▀█ ▀█▀ █▀▀ █▀█
█▀▄ ██▄ █▀▀ █▄█ █▀▄ ░█░ ██▄ █▀▄
                                  
  """
def print_logo():
    print(Fore.RED + Style.BRIGHT + logo + Style.RESET_ALL + Style.BRIGHT +"\n")
    print(Style.RESET_ALL + Style.BRIGHT, Style.BRIGHT)                                                  
    print(Fore.RED + "                                                      Youtube" + Fore.CYAN + " - Shubhu Cyber Studio ")
    print(Fore.RED + "                                                      BY     " + Fore.CYAN + " - @Guccifer Shubham")
    print(Fore.RED + "                                                      Telegram"+ Fore.CYAN + " - t.me/darksquadbyshub1hacker ")
    print(Fore.GREEN + "      Dark Squad Project: https://t.me/darksquadbyshub1hacker"+ Style.RESET_ALL + Style.BRIGHT)